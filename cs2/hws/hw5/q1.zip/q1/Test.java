class Test
{
	public static void main(String[] args)
	{
		Vector v = new Vector();
		v.Add(4);
		v.Add(3);
		v.Add(1);
		v.Add(6);
		v.Add(2);
		v.Remove(0);
		v.Remove(3);
		v.Remove(2);
		v.Remove(4);
	}
}
