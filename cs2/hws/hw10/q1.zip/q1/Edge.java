class Edge
{
	public int target;
	public Edge next;
	
	public Edge(int target)
	{
		this.target = target;
	}
}
