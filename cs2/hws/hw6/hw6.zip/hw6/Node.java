class Node
{
	public Node previous, next;
	private Object data;
	public Node(Object data)
	{
		this.data = data;
	}

	public Object GetData()		{return data;}
}
