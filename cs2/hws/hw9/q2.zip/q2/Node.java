class Node
{
	public Object key;
	public Object data;
	public Node next;

	public Node(Object key, Object data)
	{
		this.key = key;
		this.data = data;
	}
}
