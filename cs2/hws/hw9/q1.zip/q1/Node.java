class Node
{
	public Comparable key;
	public Object data;
	public Node next;

	public Node(Comparable key, Object data)
	{
		this.key = key;
		this.data = data;
	}
}
